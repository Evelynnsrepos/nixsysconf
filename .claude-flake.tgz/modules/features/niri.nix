{self, inputs, ...}: {

  flake.nixosModules.niri = { pkgs, lib, ... }: {
  programs.niri = {
  enable = true;
  package = self.packages.${pkgs.stdenv.hostPlatform.system}.myNiri;
  };
  };

  perSystem = { pkgs, lib, self', ... }: {
	packages.myNiri = inputs.wrapper-modules.wrappers.niri.wrap {
      inherit pkgs;
      settings = {
              spawn-at-startup = [
          (lib.getExe self'.packages.myNoctalia)
        ];

        xwayland-satellite.path = lib.getExe pkgs.xwayland-satellite;

        # Qt/KDE apps read their colours from ~/.config/kdeglobals (Noctalia KColorScheme
        # template) via plasma-integration; qt6ct's palette is ignored by Dolphin/Kate
        environment.QT_QPA_PLATFORMTHEME = "kde";
        # Material 3 look: Kvantum theme "KMaterial" from ~/My-repos/KMaterial-de, coloured by a Noctalia
        # user template; theme chosen in ~/.config/Kvantum/kvantum.kvconfig
        environment.QT_STYLE_OVERRIDE = "kvantum";
        input.keyboard = {
          xkb.layout = "de";
        };
        # Wacom pen through the kernel driver + libinput (pressure included); same mapping
        # OpenTabletDriver had: whole tablet onto the middle monitor
        input.tablet.map-to-output = "DP-2";
        # The Wacom's touch surface shows up as a touchpad. niri's built-in gestures:
        # 3 fingers sideways scrolls columns, up/down switches workspace, 4 fingers up/down = overview
        input.touchpad = {
          tap = _: { };
          natural-scroll = _: { };
        };
        # Focus the window under the cursor (like Hyprland), without scrolling the view to it
        input.focus-follows-mouse = _: {
          props = { max-scroll-amount = "0%"; };
        };

        # Copy of ~/.config/niri/config.kdl, updated with ~/.nixsysconf/sync-niri.sh
        include = "${./niri-config.kdl}";

        # Named workspaces, all on the middle monitor (DP-2)
        workspaces = {
          "Steam".open-on-output = "DP-2";
          "Browse".open-on-output = "DP-2";
          "Work".open-on-output = "DP-2";
          "Test".open-on-output = "DP-2";
        };

        outputs = {
          "Acer Technologies ED270U P2 A5381994F3W01" = {   # HDMI-A-1, left
            mode = "2560x1440@119.998";
            position = _: { props = { x = 0; y = 240; }; };
          };
          "Acer Technologies ED270U P2 A43011AD63W01" = {   # DP-2, middle
            mode = "2560x1440@179.998";
            position = _: { props = { x = 2560; y = 240; }; };
          };
          "LG Electronics LG ULTRAGEAR 0x0002F884" = {      # DP-3, right, portrait
            mode = "1920x1080@120.000";
            transform = "90";
            position = _: { props = { x = 5120; y = 0; }; };
          };
        };

        window-rules = [
          {
            # Slight see-through for these apps (Alacritty does its own, see alacritty.toml)
            matches = [
              { app-id = "^discord$"; }
              { app-id = "^Spotify$"; }
              { app-id = "^spotify$"; }
              { app-id = "^org.kde.dolphin$"; }
              { app-id = "^org.kde.kate$"; }
            ];
            opacity = 0.92;
          }
          {
            matches = [ { app-id = "^discord$"; } ];
            open-on-output = "DP-3";   # right LG (portrait)
            open-maximized = true;
          }
          {
            matches = [ { app-id = "^[Ss]potify$"; } ];
            open-on-output = "HDMI-A-1";   # left Acer
            open-maximized = true;
          }
          {
            matches = [ { app-id = "^steam$"; } ];
            open-on-workspace = "Steam";   # workspace lives on DP-2
            open-maximized = true;
          }
          {
            # Zen Flatpak (app.zen_browser.zen) reports app-id "zen"
            matches = [ { app-id = "^(zen|app\\.zen_browser\\.zen)$"; } ];
            open-on-workspace = "Browse";
            open-maximized = true;
          }
          {
            matches = [
              { app-id = "(?i)^claude"; }
              { title = "^Eve\\.Lopment Games Designer"; }
            ];
            open-on-workspace = "Work";
            open-maximized = true;
          }
        ];

        binds = {
          "Mod+T".spawn-sh = lib.getExe pkgs.alacritty;
          "Mod+Return".spawn-sh = lib.getExe pkgs.kitty;
          "Mod+Q".close-window = _: { };
          "Mod+D".spawn-sh = "${lib.getExe self'.packages.myNoctalia} msg panel-toggle launcher";
          "Mod+E".spawn-sh = lib.getExe pkgs.kdePackages.dolphin;
          "Mod+A".toggle-overview = _: { };
          # niri's own region screenshot: freezes all monitors, drag a rectangle
          "Mod+Shift+S".screenshot = _: { };
        };
      };


};
};
}
